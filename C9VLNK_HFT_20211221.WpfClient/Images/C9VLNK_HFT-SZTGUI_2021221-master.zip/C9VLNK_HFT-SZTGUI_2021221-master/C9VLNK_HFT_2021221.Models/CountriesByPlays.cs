﻿namespace C9VLNK_HFT_2021221.Models
{
    public class CountriesByPlays
    {
        public Countries CountryName { get; set; }
        public int Plays { get; set; }
    }
}
