﻿using C9VLNK_HFT_2021221.Models;

namespace C9VLNK_HFT_20211221.WpfClient.Services
{
    public interface IArtistEditorService
    {
        void EditArtist(Artist artist);
    }
}