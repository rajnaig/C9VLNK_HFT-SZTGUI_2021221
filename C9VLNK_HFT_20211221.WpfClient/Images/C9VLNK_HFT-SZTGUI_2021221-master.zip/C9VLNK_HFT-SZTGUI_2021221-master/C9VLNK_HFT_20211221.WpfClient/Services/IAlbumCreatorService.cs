﻿namespace C9VLNK_HFT_20211221.WpfClient.Services
{
    public interface IAlbumCreatorService
    {
        void CreateAlbum();
    }
}