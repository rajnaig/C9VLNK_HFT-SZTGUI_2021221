﻿using System.Windows.Controls;

namespace C9VLNK_HFT_20211221.WpfClient.View
{
    /// <summary>
    /// Interaction logic for CrudFiltersView.xaml
    /// </summary>
    public partial class CrudFiltersView : UserControl
    {
        public CrudFiltersView()
        {
            InitializeComponent();
        }
    }
}
