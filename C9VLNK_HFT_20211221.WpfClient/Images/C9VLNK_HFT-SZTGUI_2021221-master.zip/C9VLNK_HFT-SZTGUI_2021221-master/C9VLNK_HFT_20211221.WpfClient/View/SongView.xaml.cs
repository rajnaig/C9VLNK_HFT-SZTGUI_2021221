﻿using System.Windows.Controls;

namespace C9VLNK_HFT_20211221.WpfClient.View
{
    /// <summary>
    /// Interaction logic for SongView.xaml
    /// </summary>
    public partial class SongView : UserControl
    {
        public SongView()
        {
            InitializeComponent();
        }
    }
}
