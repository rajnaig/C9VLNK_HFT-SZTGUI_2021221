﻿using System.Windows.Controls;

namespace C9VLNK_HFT_20211221.WpfClient.View
{
    /// <summary>
    /// Interaction logic for AlbumView.xaml
    /// </summary>
    public partial class AlbumView : UserControl
    {
        public AlbumView()
        {
            InitializeComponent();
        }
    }
}
