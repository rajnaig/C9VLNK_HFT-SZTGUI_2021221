﻿using System.Windows.Controls;

namespace C9VLNK_HFT_20211221.WpfClient.View
{
    /// <summary>
    /// Interaction logic for ArtistView.xaml
    /// </summary>
    public partial class ArtistView : UserControl
    {
        public ArtistView()
        {
            InitializeComponent();
        }
    }
}
