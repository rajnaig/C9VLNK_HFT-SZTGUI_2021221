﻿using System.Windows.Controls;

namespace C9VLNK_HFT_20211221.WpfClient.View
{
    /// <summary>
    /// Interaction logic for HomeView.xaml
    /// </summary>
    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }

        
    }
}
